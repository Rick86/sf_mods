﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SF_LogViewer
{
    public partial class Form1 : Form
    {
        string configPath = Application.StartupPath + "\\SF_LogViewerConfig.cfg";
        int lastLine = 0;
        int ignoreLinesLessThan = 0;

        public Form1()
        {
            try
            {
                InitializeComponent();

                ReadConfig();
                UpdateTimer();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReadConfig()
        {
            if (File.Exists(configPath))
            {
                string[] configLines = File.ReadAllLines(configPath);

                if (configLines.Length == 4)
                {
                    txtLogPath.Text = configLines[0];
                    txtLogFilter.Text = configLines[1];

                    bool autoRefresh = bool.Parse(configLines[2]);
                    bool clearOnStart = bool.Parse(configLines[3]);
                    chkAutoUpdate.Checked = autoRefresh;
                    chkClearOnStart.Checked = clearOnStart;

                    if (clearOnStart)
                    {
                        Clear();
                    }
                }
            }
        }

        private string GetLogPath()
        {
            return Environment.ExpandEnvironmentVariables(txtLogPath.Text);
        }

        private void RefreshLog()
        {
            try
            {
                string logPath = GetLogPath();
                string logFilter = txtLogFilter.Text;

                if(ignoreLinesLessThan > lastLine)
                {
                    ignoreLinesLessThan = 0;
                }

                if (string.IsNullOrEmpty(logPath))
                {
                    throw new Exception("Please specify a valid log path.");
                }
                else if (!File.Exists(logPath))
                {
                    throw new Exception("File not found: " + logPath);
                }
                else
                {
                    List<string> logLines = new List<string>();
                    string logText = "";
                    int currentLine = 0;
                    using (var logFileStream = new FileStream(logPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    using (var logReader = new StreamReader(logFileStream, Encoding.Default))
                    {
                        while (logReader.Peek() >= 0)
                        {
                            string logLine = logReader.ReadLine();
                            currentLine++;

                            if (ignoreLinesLessThan == 0 || currentLine > ignoreLinesLessThan)
                            {
                                if (currentLine > lastLine)
                                {
                                    lastLine = currentLine;
                                }

                                if (string.IsNullOrEmpty(logFilter) || logLine.Contains(logFilter))
                                {
                                    if (!string.IsNullOrEmpty(logText))
                                    {
                                        logText += Environment.NewLine;
                                    }

                                    logText += logLine;
                                }
                            }
                        }
                    }

                    if (string.IsNullOrEmpty(logText))
                    {
                        logText = "NOTHING FOUND...";
                    }

                    if (txtLog.Text != logText)
                    {
                        txtLog.Text = "";
                        txtLog.AppendText(logText);
                    }
                }
            }
            catch (Exception ex)
            {
                StopTimer();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshLog();
        }

        private void timerRefresh_Tick(object sender, EventArgs e)
        {
            RefreshLog();
        }

        private void StartTimer()
        {
            chkAutoUpdate.Checked = true;
            timerRefresh.Enabled = true;
            timerRefresh.Start();
        }

        private void StopTimer()
        {
            timerRefresh.Stop();
            chkAutoUpdate.Checked = false;
            timerRefresh.Enabled = false;
        }

        private void UpdateTimer()
        {
            if (chkAutoUpdate.Checked)
            {
                StartTimer();
            }
            else
            {
                StopTimer();
            }
        }

        private void chkAutoUpdate_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTimer();
        }

        private void btnClearLogFile_Click(object sender, EventArgs e)
        {
            try
            {
                string logPath = GetLogPath();
                bool wasAutoUpdate = false;
                string msgText = "";
                msgText += "Are you sure you want to clear the Log-File (" + logPath + ")?" + Environment.NewLine + Environment.NewLine;
                msgText += "This will delete the content of the file, but a backup will be created." + Environment.NewLine + Environment.NewLine;
                msgText += "Note: This only works outside of the game.";
                
                var messageResult = MessageBox.Show(msgText, "Clear Log-File", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (messageResult == DialogResult.Yes)
                {
                    if (chkAutoUpdate.Checked)
                    {
                        wasAutoUpdate = true;
                        StopTimer();
                    }

                    // get file name infos
                    string dateNow = DateTime.Now.ToString("yyyy_MM_dd__HH_mm_ss_fff");
                    string fileFolder = Path.GetDirectoryName(logPath);
                    string fileName = Path.GetFileNameWithoutExtension(logPath);
                    string fileExt = Path.GetExtension(logPath);
                    string backupPath = fileFolder + "\\" + fileName + "_OLD_" + dateNow + fileExt;

                    // make backup of file
                    File.Copy(logPath, backupPath);

                    // empty file
                    File.WriteAllText(logPath, "");

                    // start timer (if it was started before)
                    if (wasAutoUpdate)
                    {
                        StartTimer();
                    }

                    MessageBox.Show("Log cleared, backup: " + backupPath, "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clear()
        {
            RefreshLog();

            ignoreLinesLessThan = lastLine;
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnSaveConfig_Click(object sender, EventArgs e)
        {
            string configContent = "";
            configContent += txtLogPath.Text + Environment.NewLine;
            configContent += txtLogFilter.Text + Environment.NewLine;
            configContent += chkAutoUpdate.Checked.ToString().ToUpper() + Environment.NewLine;
            configContent += chkClearOnStart.Checked.ToString().ToUpper();

            File.WriteAllText(configPath, configContent);

            MessageBox.Show("Saved at: " + configPath, "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnReloadLog_Click(object sender, EventArgs e)
        {
            ignoreLinesLessThan = 0;
            RefreshLog();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            string helpText = "";
            helpText += "Clear Log: Clears Log-Textfield and only shows NEW content." + Environment.NewLine + Environment.NewLine;
            helpText += "Clear Log-File: Clears / deletes the content of the Logfile (a backup will be created before). This works only OUTSIDE of the game." + Environment.NewLine + Environment.NewLine;
            helpText += "Reload Log: Reads the current Logfile and resets the \"only show new content\" filter (displays old content, if you cleared the log before)." + Environment.NewLine + Environment.NewLine;
            helpText += "Save Config: Well... ;)" + Environment.NewLine + Environment.NewLine;
            helpText += "Refresh: Reads the current Logfile with the filters, same as the \"Auto-Refresh\"." + Environment.NewLine + Environment.NewLine;
            helpText += "Logfile-Path: " + GetLogPath() + Environment.NewLine + Environment.NewLine;
            helpText += "Config-Path: " + configPath;

            

            MessageBox.Show(helpText, "Help", MessageBoxButtons.OK, MessageBoxIcon.Question);
        }
    }
}
